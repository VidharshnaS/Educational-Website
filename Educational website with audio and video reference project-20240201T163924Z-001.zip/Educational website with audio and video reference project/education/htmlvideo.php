<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Video</title>
</head>
<body>
<video width="320" height="240" controls>
  <source src="Addition.mp4" type="video/mp4">
  <source src="Addition.ogg" type="video/ogg">
Your browser does not support the video tag.
</video>
</body>
</html>
