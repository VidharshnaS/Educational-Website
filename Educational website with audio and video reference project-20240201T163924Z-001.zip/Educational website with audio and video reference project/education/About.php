<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Educational Website</title>
	<link rel="stylesheet" type="text/css" href="styleabout.css">
</head>
<body>
  <header id="header">
  <a href="#" class="logo">Website for Education</a>
  </header>
  <ul class="navigation">
      <li><a href="index.php">Home</a></li>
      <li><a href="#" class="active">About</a></li>
      <li><a href="login.php">Login</a></li>
      <li><a href="Register.php">Register</a></li>
    </ul>
    <div class="about">
    <h2>Educational Website for coding learners</h2>
    <p>There are numerous websites that provide resources for learning how to code. Here are some popular websites provide codes like C, C++, Java, etc..., but no one gives a proper explaining about the coding. Like, W3Schools, JavaPoint, Codecademy of popular websites gives a proper code but no good explanation.</p>
    <p>That's why am provide in this project, mainly focus on understanding of the learners who feel better to learn with the help of audio and video not only with comment lines.This project explains basic coding's of C, C++, Java, Python, Html with comment lines as well as audio and video.The coding gives a glimpse of major concepts of OOP’s which will be of more use to students who prepare for their exams in last minute.</p>
  </div>
</body>
</html>